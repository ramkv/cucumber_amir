package restassuredexample.cucumber;

public abstract class InternationalSpaceStationCurrentLocationConfiguration {

    public static final String OPEN_NOTIFY_API_URI = "http://api.open-notify.org";

}
